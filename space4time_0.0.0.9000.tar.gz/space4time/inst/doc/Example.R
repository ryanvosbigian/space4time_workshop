## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(space4time)
library(dplyr)
library(ggplot2)

## ----echo=FALSE---------------------------------------------------------------

EFPTRP_age_data <- read.csv("EFPTRP_2015_2019_age.csv") %>%
  dplyr::select(id = PITCode,obs_time = SurveyYear,SurveyDate,FL = FLength,Bin,Season,ageclass = Age)


## -----------------------------------------------------------------------------
EFPTRP_age_data[10:15,]%>%
  knitr::kable(row.names = FALSE)

## -----------------------------------------------------------------------------

# identify individuals with more than one observation at the RST in the data
EFPTRP_age_data %>%
  dplyr::group_by(id) %>% # groups data by ID
  dplyr::arrange(id,SurveyDate) %>% # sorts by ID and date
  dplyr::mutate(Obs = dplyr::n()) %>% # creates a column that is the number of times
                                      # each individual is in the data
  filter(Obs > 1) # filter for multiple observations

# identify missing data
EFPTRP_age_data %>%
  dplyr::filter(is.na(FL)) # filter for FL as NA

# drop duplicate observations (keep the first observation) and missing data
EFPTRP_age_data <- EFPTRP_age_data %>%
  dplyr::group_by(id) %>%
  dplyr::arrange(id,SurveyDate) %>%
  dplyr::summarize(         # summarizes by id, so it returns 1 row per id
            id = dplyr::first(id), # retains the first value
            SurveyDate = dplyr::first(SurveyDate),
            obs_time = dplyr::first(obs_time), 
            FL = dplyr::first(FL),
            Bin = dplyr::first(Bin),
            Season = dplyr::first(Season),
            ageclass = dplyr::first(ageclass)
            # obs_site = first(obs_site), # save the first observation of any additional variables
            ) %>%
  dplyr::filter(!is.na(FL)) 

## -----------------------------------------------------------------------------
# create histogram to visualize the distribution of fork lengths
# hist(EFPTRP_age_data$FL,breaks = 50)


EFPTRP_age_data <- EFPTRP_age_data %>%
  dplyr::mutate(Bin = dplyr::case_when(FL < 80 ~ 80, # if FL < 80, return 80
                                       FL >180 ~ 180, # if FL greater than 180, return 180
                                       # otherwise, round FL to the nearest 10 mm.
                                       FL >= 80 & FL <= 180 ~ round(FL,-1)), 
                Bin_sc = (Bin - mean(Bin)) / stats::sd(Bin)) # z-scale Bin


## -----------------------------------------------------------------------------
proc_DART_data <- read_DART_file(filepath = "pitbasin_branching_upload_1759171262_907.csv",
               aux_age_df = EFPTRP_age_data,
               DART_config = "sites_config.txt")

## -----------------------------------------------------------------------------
ch_df <- proc_DART_data$ch_df
head(ch_df)

aux_age_df <- proc_DART_data$aux_age_df

head(aux_age_df)

## -----------------------------------------------------------------------------
table(aux_age_df$ageclass)

## -----------------------------------------------------------------------------
table(ch_df$site)

## -----------------------------------------------------------------------------
ch_df2 <- remove_kelt_obs(ch_df = ch_df,kelt_obssite = "GRA")

## -----------------------------------------------------------------------------
# only keep observations in the following sites
ch_df3 <- ch_df2 %>% 
  dplyr::filter(site %in% c("EFPTRP","POTREF","GOJ","GRJ","LMJ","MCJ","TWX","JDJ","BCC","B2J")) 

## ----message = FALSE----------------------------------------------------------
# returns a data frame of the ages of known age fish at different observations
ch_df %>%
  dplyr::left_join(aux_age_df,by = "id") %>%  # merge age data with capture history
  dplyr::filter(!is.na(ageclass)) %>% # only check observations of known age fish
  dplyr::mutate(Age_at_obs = ageclass + (time - obs_time)) %>% # calculate known age
  dplyr::group_by(site,Age_at_obs) %>% # group by site and age at site
  dplyr::summarise(N = dplyr::n()) # summarize number of observations


## -----------------------------------------------------------------------------
table(ch_df3$site)

## -----------------------------------------------------------------------------
ef_pot_site_config <- simplebranch_s4t_config(sites_names = c("EFPTRP",
                                                        "POTREF",
                                                        "GRJ","GOJ","LMJ","MCJ","JDJ",
                                                        "BCC",
                                                        "TWX"),
                                              branch_sites = c("EFPTRP",
                                                          "POTREF"),
                                       holdover_sites = c("EFPTRP",
                                                          "POTREF"),
                                       sites_to_pool = list("EFPTRP" = c("EFPTRP","POTREF"),
                                                            "GOJ" = c("LMJ","MCJ","JDJ",
                                                                      "BCC","TWX")),
                                       min_a = c("EFPTRP" = 1,
                                                 "POTREF" = 1,
                                                 "GRJ" = 1,
                                                 "GOJ" = 1,
                                                 "LMJ" = 1,
                                                 "MCJ" = 1,
                                                 "JDJ" = 1,
                                                 "BCC" = 1,
                                                 "TWX" = 1),
                                       max_a = c("EFPTRP" = 3,
                                                 "POTREF" = 3,
                                                 "GRJ" = 3,
                                                 "GOJ" = 3,
                                                 "LMJ" = 3,
                                                 "MCJ" = 3,
                                                 "JDJ" = 3,
                                                 "BCC" = 3,
                                                 "TWX" = 3)

)

print(ef_pot_site_config)

## -----------------------------------------------------------------------------
efp_s4_ch <- s4t_ch(ch_df = ch_df3,aux_age_df = aux_age_df,s4t_config = ef_pot_site_config)

## -----------------------------------------------------------------------------
clean_ch_df <- clean_s4t_ch_obs(efp_s4_ch)

## ----eval = FALSE-------------------------------------------------------------
# 
# # show dropped observations
# clean_ch_df$dropped_ch_df
# 
# # show full observation history of individuals with dropped observations
# clean_ch_df$intermediate_ch_df %>%
#   dplyr::group_by(id) %>% # group by ID
#   dplyr::filter(any(drop_obs == TRUE)) %>% # keep only individuals with dropped observations
#   head() # print out only the first 6 observations
# 
# 
# # can inspect individuals
# 
# # aux_age_df %>%
# #   dplyr::filter(id == "3DD.00778C962F")
# 
# # clean_ch_df$intermediate_ch_df %>%
# #   dplyr::filter(id == "3DD.00778C962F")
# 

## -----------------------------------------------------------------------------
efp_s4_ch2 <- s4t_ch(ch_df = clean_ch_df$cleaned_ch_df,aux_age_df = aux_age_df,s4t_config = ef_pot_site_config)

## -----------------------------------------------------------------------------
# annual summaries
aux_age_df %>%
  dplyr::filter(!is.na(ageclass)) %>% # only include observations with ages
  dplyr::group_by(obs_time,ageclass) %>% # group by age and obs_time (year)
  dplyr::summarize(mean_FL = mean(FL), # mean FL
            sd_FL = stats::sd(FL),   # sd of FL
            N = dplyr::n())          # number of observations


# create boxplot of fork length by ages
aux_age_df %>% 
  dplyr::filter(!is.na(ageclass)) %>% # only include observations with ages
  ggplot2::ggplot(ggplot2::aes(factor(ageclass), FL)) +
  geom_boxplot() +
  facet_wrap(~obs_time) +
  theme_bw() +
  labs(x = "Age",y = "Fork length (mm)")
  
  

## -----------------------------------------------------------------------------

age_mod1 <- fit_ageclass(age_formula = ~ I(factor(obs_time)) + Bin_sc,
                         s4t_ch = efp_s4_ch2)

age_mod2 <- fit_ageclass(age_formula = ~ I(factor(obs_time)) * Bin_sc,
                         s4t_ch = efp_s4_ch2)

age_mod3 <- fit_ageclass(age_formula = ~ I(factor(obs_time)) + I(factor(Bin)),
                         s4t_ch = efp_s4_ch2)


## -----------------------------------------------------------------------------
plot(age_mod1)

## -----------------------------------------------------------------------------
AIC(age_mod1,age_mod2,age_mod3)

## -----------------------------------------------------------------------------
# Allows for parallel computation (reduces overall time)
rstan::rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

s4t_m1 <- fit_s4t_cjs_rstan(p_formula = ~ t,
                            theta_formula = ~ a1 * a2 * s * j,
                            ageclass_formula = ~ I(factor(obs_time)) + Bin_sc,
                            fixed_age = FALSE,
                            s4t_ch = efp_s4_ch2)


s4t_m2 <- fit_s4t_cjs_rstan(p_formula = ~ t * a2,
                            theta_formula = ~ a1 * a2 * s * j,
                            ageclass_formula = ~ I(factor(obs_time)) + Bin_sc,
                            fixed_age = FALSE,
                            s4t_ch = efp_s4_ch2)

# full model
s4t_m3 <- fit_s4t_cjs_rstan(p_formula = ~ t * a1 * a2,
                            theta_formula = ~ a1 * a2 * s * j,
                            ageclass_formula = ~ I(factor(obs_time)) + Bin_sc,
                            fixed_age = FALSE,
                            s4t_ch = efp_s4_ch2)

# optionally save model objects
# save(s4t_m1,s4t_m2,s4t_m3, file = "EF_Potlatch_s4t.RData")


## -----------------------------------------------------------------------------
s4t_m1

## ----dpi=300,fig.height = 5,fig.width=7---------------------------------------
traceplot.s4t_cjs_rstan(s4t_m1)

## -----------------------------------------------------------------------------
library(loo)


loo_m1 <- loo(extract_log_lik_s4t(s4t_m1))
loo_m2 <- loo(extract_log_lik_s4t(s4t_m2))
loo_m3 <- loo(extract_log_lik_s4t(s4t_m3))

loo::loo_compare(loo_m1,loo_m2,loo_m3)

## -----------------------------------------------------------------------------
s4t_m1$cohort_transitions %>% head()

## -----------------------------------------------------------------------------
s4t_m1$apparent_surv %>% head()

## ----dpi=300,fig.height = 5,fig.width=7---------------------------------------
# currently the textsize must be set to include filters, which are j == "EFPTRP"
# in this example
plotTransitions(s4t_m1,textsize = 3,j == "EFPTRP")

## ----dpi=300,fig.height = 5,fig.width=7---------------------------------------
plotSurvival(s4t_m1,textsize = 3,j == "EFPTRP")

## ----dpi=300,fig.height = 5,fig.width=7---------------------------------------
s4t_m1$apparent_surv %>%
  dplyr::filter(k == "GRJ") %>%
  dplyr::mutate(age = factor(a1)) %>%
  ggplot2::ggplot(ggplot2::aes(s, mean, color = age,group = age)) +
  ggplot2::geom_point() + 
  ggplot2::geom_errorbar(ggplot2::aes(ymin = `2.5%`,
                                      ymax = `97.5%`),
                         width = 0.05,
                         linewidth = 1,
                         alpha = 0.5) + 
  ggplot2::geom_line() +
  ggplot2::theme_bw() +
  ggplot2::labs(x = "Release year",
                y = "Apparent survival",
                color = "Age")
  

## ----dpi=300,fig.height = 5,fig.width=7---------------------------------------
s4t_m1$cohort_transitions %>%
  dplyr::filter(k == "GRJ") %>%
  dplyr::mutate(age = paste0("Age-",a1),
                holdover = factor(a2-a1)) %>%
  ggplot2::ggplot(ggplot2::aes(s, mean, color = holdover,group = holdover)) +
  ggplot2::geom_point() + 
  ggplot2::geom_errorbar(ggplot2::aes(ymin = `2.5%`,
                                      ymax = `97.5%`),
                         width = 0.05,
                         linewidth = 1,
                         alpha = 0.5) + 
  ggplot2::geom_line() +
  ggplot2::facet_wrap(~age) +
  ggplot2::theme_bw() +
  ggplot2::labs(x = "Release year",
                y = "Transition probabilities",
                color = "Holdover (yrs)")

## ----echo = FALSE-------------------------------------------------------------
fake_abundance_data <- data.frame(j = "EFPTRP",
                                  s = c(2015,2015,2015,
                                        2016,2016,2016,
                                        2017,2017,2017,
                                        2018,2018,2018,
                                        2019,2019,2019),
                                  a1 = c(1,2,3,
                                         1,2,3,
                                         1,2,3,
                                         1,2,3,
                                         1,2,3),
                                  abundance = round(runif(15,10,1000)),
                                  abundance_se = 0)

## -----------------------------------------------------------------------------
# format of abund argument using fake (simulated) data.
head(fake_abundance_data)

# compute cohort specific abundances
cohort_abundance_at_LGR = abundance_estimates(s4t_m1,abund = fake_abundance_data,type = "None")

head(cohort_abundance_at_LGR)

# summarize by broodyear, site, and group.
broodyear_abundance_at_LGR = abundance_estimates(s4t_m1,abund = fake_abundance_data,type = "BroodYear")

head(broodyear_abundance_at_LGR)

