## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(space4time)

## ----eval = FALSE, echo = FALSE-----------------------------------------------
# "
# For instance, the probability that an individual transitions from site `1` to site `2` given that it passed site `1` at time `1` during age `1` and passes site `2` during age `2` is $\Theta_{j=1,k=2,s=1,a_1=1,a_2=2}$. The probability that they are observed at site `2` (given that they were observed at site `1`) is $\Theta_{j=1,k=2,s=1,a_1=1,a_2=2} *p_{j=1,k=2,t=2,a_1=1,a_2=2}$. The probability that they are not observed is $\Theta_{j=1,k=2,s=1,a_1=1,a_2=2} *(1 - p_{j=1,k=2,t=2,a_1=1,a_2=2})$. The probability t
# "

## ----simulate data------------------------------------------------------------
set.seed(1)
sim.dat <- sim_simple_s4t_ch(N = 800)

s4t_ch <- sim.dat$s4t_ch

## ----echo= FALSE--------------------------------------------------------------
ch_df = s4t_ch$obs_data$ch_df
knitr::kable(head(s4t_ch$obs_data$ch_df))

## ----echo= FALSE--------------------------------------------------------------
aux_df <- s4t_ch$obs_data$all_aux
knitr::kable(cbind(id = 1:6,head(s4t_ch$obs_data$all_aux)))

## ----echo=FALSE---------------------------------------------------------------
print(s4t_ch$s4t_config)

## ----eval = FALSE-------------------------------------------------------------
# ex_config <- linear_s4t_config(sites_names = 1:3, # vector of site names
#                                holdover_sites = 1,# which site (or sites) do
#                                # individuals holdover before continuing to the next site
#                                min_a = c(1,1,1), # for each site, the minimum possible age
#                                max_a = c(3,3,3)) # for each site, the maximum possible age

## ----eval = FALSE-------------------------------------------------------------
# ex_ch <- s4t_ch(ch_df = ch_df,
#                 aux_age_df = aux_df,
#                 s4t_config = ex_config)

## -----------------------------------------------------------------------------
age_m1 <- fit_ageclass(age_formula = ~ 1,s4t_ch = s4t_ch)

age_m2 <- fit_ageclass(age_formula = ~ FL,s4t_ch = s4t_ch)

# note that obs_time is treated as a factor (see fit_ageclass documentation)
age_m3 <- fit_ageclass(age_formula = ~ FL + obs_time,s4t_ch = s4t_ch)



## -----------------------------------------------------------------------------
AIC(age_m1, 
    age_m2, 
    age_m3)

## ----message=FALSE------------------------------------------------------------
m1 <- fit_s4t_cjs_rstan(
      p_formula = ~ t,
      theta_formula = ~ a1 * a2 * s * j,
      ageclass_formula = ~ FL,
      fixed_age = TRUE,
      s4t_ch = s4t_ch,
      chains = 2,
      warmup = 200,
      iter = 600
    )



## -----------------------------------------------------------------------------
print(m1)

## ----eval = FALSE-------------------------------------------------------------
# traceplot(m1,pars = "theta")
# 
# traceplot(m1,pars = "^p") # regular expressions for all parameters that start with "p"

## ----fig.height=4,fig.width=6-------------------------------------------------
plotSurvival(m1)

## ----fig.height=4,fig.width=6-------------------------------------------------
plotTransitions(m1,textsize = 3, j == 1) # only include transitions that start from site 1

