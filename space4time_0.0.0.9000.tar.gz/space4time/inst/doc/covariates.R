## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(space4time)

## -----------------------------------------------------------------------------
set.seed(1)
sim.dat <- sim_simple_s4t_ch()
s4t_ch <- sim.dat$s4t_ch

temperature_data <- data.frame(s =    c(1, 2, 3, 4,
                                        1, 2, 3, 4),
                               j =    c(1, 1, 1, 1,
                                        2, 2, 2, 2),
                               temp = c(12.1,13.4,11.3,15.3,
                                        18.4,19.2,17.8,20.3)
                               )

# center and scale data
temperature_data$temp <- scale(temperature_data$temp)


## -----------------------------------------------------------------------------
s4t_ch2 <- add_covariates(cov_df = temperature_data,
                          s4t_ch = s4t_ch)

## ----eval = FALSE-------------------------------------------------------------
# m1 <- fit_s4t_cjs_rstan(p_formula = ~ t,
#                         theta_formula = ~ a1 * a2 * temp * j,
#                         ageclass_formula =  ~ FL,
#                         s4t_ch = s4t_ch2,
#                         fixed_age = TRUE)
# 
# m2 <- fit_s4t_cjs_rstan(p_formula = ~ t,
#                         theta_formula = ~ a1 : a2 : temp + j + a1 * a2 * s,
#                         ageclass_formula =  ~ FL,
#                         s4t_ch = s4t_ch2,
#                         fixed_age = TRUE)
# 
# 
# m3 <- fit_s4t_cjs_rstan(p_formula = ~ t,
#                         theta_formula = ~ a1 : a2 : temp * j+ a1 * a2 * j,
#                         ageclass_formula =  ~ FL,
#                         s4t_ch = s4t_ch2,
#                         fixed_age = TRUE)
# 
# m2 <- fit_s4t_cjs_rstan(p_formula = ~ t,
#                         theta_formula = ~ temp + a1 * a2 * j,
#                         ageclass_formula =  ~ FL,
#                         s4t_ch = s4t_ch2,
#                         fixed_age = TRUE)
# 

